
import React from 'react';
import { 
  Users, 
  Layers, 
  TrendingUp, 
  Heart,
  ArrowUpRight,
  ArrowDownRight,
  MoreVertical,
  Globe,
  Activity,
  DollarSign,
  PieChart,
  ShieldAlert,
  Zap,
  Target,
  Clock,
  Calendar,
  MapPin,
  CheckCircle2,
  ShieldCheck,
  ArrowRight
} from 'lucide-react';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Cell as RechartsCell
} from 'recharts';
import { MOCK_TENANT, MOCK_MEMBERS, MOCK_CELLS, MOCK_PRAYER_REQUESTS, PLAN_CONFIGS } from '../constants';
import { LadderStage, UserRole, PrayerStatus } from '../types';

const dataGrowth = [
  { name: 'Jan', members: 380, revenue: 12000 },
  { name: 'Fev', members: 395, revenue: 13500 },
  { name: 'Mar', members: 410, revenue: 14200 },
  { name: 'Abr', members: 405, revenue: 13800 },
  { name: 'Mai', members: 425, revenue: 15500 },
  { name: 'Jun', members: 450, revenue: 18000 },
];

const StatCard = ({ title, value, trend, icon, color, subValue }: any) => (
  <div className="bg-zinc-900 p-8 rounded-[2rem] border border-white/5 shadow-2xl hover:bg-zinc-800 transition-all group overflow-hidden relative">
    <div className="flex justify-between items-start mb-6">
      <div className={`p-4 rounded-2xl ${color} shadow-lg shadow-black/20`}>
        {icon}
      </div>
      <button className="text-zinc-600 hover:text-zinc-300">
        <MoreVertical size={20} />
      </button>
    </div>
    <p className="text-zinc-500 text-xs font-black uppercase tracking-[0.15em] mb-2">{title}</p>
    <div className="flex items-baseline gap-3">
      <h3 className="text-3xl font-black text-white tracking-tighter">{value}</h3>
      {subValue && <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-tight">{subValue}</span>}
    </div>
    {trend !== undefined && (
      <div className="flex items-center gap-2 mt-4">
        <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase ${trend > 0 ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>
          {trend > 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />} {Math.abs(trend)}%
        </div>
        <span className="text-zinc-600 text-[10px] font-bold uppercase">vs mês passado</span>
      </div>
    )}
  </div>
);

const MasterDashboard = () => (
  <div className="space-y-10 animate-in fade-in duration-700">
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
      <div>
        <h2 className="text-4xl font-black text-white tracking-tighter">Global Control</h2>
        <p className="text-zinc-500 font-medium text-lg">Visão estratégica e saúde do ecossistema SaaS.</p>
      </div>
      <div className="flex items-center gap-3 text-[10px] font-black text-zinc-400 bg-zinc-900 border border-white/5 px-5 py-3 rounded-2xl shadow-2xl">
        <Activity size={14} className="text-emerald-500 animate-pulse" /> INFRA ESTRUTURA ONLINE • JUN 2024
      </div>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      <StatCard title="Total de Clientes" value="124" trend={5} icon={<Globe className="text-blue-400" />} color="bg-blue-500/10" />
      <StatCard title="MRR Mensal" value="R$ 42.500" trend={12} icon={<DollarSign className="text-emerald-400" />} color="bg-emerald-500/10" />
      <StatCard title="Novas Instâncias" value="14" trend={20} icon={<Zap className="text-amber-400" />} color="bg-amber-500/10" />
      <StatCard title="Churn Global" value="1.2%" trend={-0.5} icon={<ShieldAlert className="text-rose-400" />} color="bg-rose-500/10" />
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
      <div className="lg:col-span-2 bg-zinc-900 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl">
        <h4 className="font-black text-white text-xl mb-10 flex items-center gap-4 uppercase tracking-tighter">
          <div className="w-1.5 h-6 bg-blue-600 rounded-full" /> Receita & Performance (6 Meses)
        </h4>
        <div className="h-[350px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={dataGrowth}>
              <defs>
                <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#27272a" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#52525b', fontSize: 11, fontWeight: 'bold'}} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#52525b', fontSize: 11, fontWeight: 'bold'}} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#18181b', borderRadius: '16px', border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.5)' }}
                itemStyle={{ color: '#fff', fontWeight: 'bold' }}
              />
              <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={4} fill="url(#colorRev)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      <div className="bg-zinc-100 p-10 rounded-[3rem] text-zinc-950 shadow-2xl relative overflow-hidden flex flex-col justify-between">
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <PieChart size={180} />
        </div>
        <div>
          <Zap size={48} className="mb-8 text-blue-600 fill-blue-600/20" />
          <h4 className="text-3xl font-black mb-2 tracking-tighter">SaaS Health</h4>
          <p className="text-zinc-500 text-sm mb-12 font-bold uppercase tracking-widest">Carga por Plano</p>
          <div className="space-y-8">
            {[
              { name: 'Enterprise', val: 12, color: 'bg-indigo-600' },
              { name: 'Pro', val: 48, color: 'bg-blue-600' },
              { name: 'Basic', val: 40, color: 'bg-zinc-400' },
            ].map(p => (
              <div key={p.name}>
                <div className="flex justify-between text-[10px] font-black uppercase tracking-widest mb-2 opacity-60">
                  <span>{p.name}</span>
                  <span>{p.val}%</span>
                </div>
                <div className="w-full bg-zinc-950/5 h-2 rounded-full overflow-hidden">
                  <div className={`${p.color} h-full rounded-full transition-all duration-1000`} style={{width: `${p.val}%`}}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <button className="mt-12 w-full py-5 bg-zinc-950 text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest shadow-2xl hover:scale-105 transition-all">Relatório Completo</button>
      </div>
    </div>
  </div>
);

const ChurchAdminDashboard = () => {
  const planLimits = PLAN_CONFIGS[MOCK_TENANT.plan];
  const memberPercent = (MOCK_TENANT.stats.totalMembers / planLimits.maxMembers) * 100;
  const cellPercent = (MOCK_TENANT.stats.activeCells / planLimits.maxCells) * 100;

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter uppercase">Painel Administrativo</h2>
          <p className="text-zinc-500 font-medium text-lg italic">Gerenciamento operacional da {MOCK_TENANT.name}.</p>
        </div>
        <div className="flex items-center gap-3">
           <span className="px-5 py-2.5 bg-blue-600/10 text-blue-500 rounded-2xl text-[10px] font-black border border-blue-500/20 uppercase tracking-widest">PLANO {MOCK_TENANT.plan}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <StatCard title="Fluxo de Caixa" value="R$ 18.250" trend={8} icon={<DollarSign className="text-emerald-400" />} color="bg-emerald-500/10" />
        <StatCard title="Entradas (Mês)" value="R$ 5.400" trend={15} icon={<ArrowUpRight className="text-blue-400" />} color="bg-blue-500/10" />
        <StatCard title="Pendências" value="3" subValue="relatórios" icon={<Clock className="text-amber-400" />} color="bg-amber-500/10" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="bg-zinc-900 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5"><Zap size={100} /></div>
          <h4 className="font-black text-white text-xl mb-12 flex items-center gap-4 uppercase tracking-tighter">
            <div className="w-1.5 h-6 bg-blue-600 rounded-full" /> Limites de Escala
          </h4>
          <div className="space-y-12">
            <div>
              <div className="flex justify-between mb-3 items-end">
                <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Membros Ativos</span>
                <span className="text-xs font-black text-white">{MOCK_TENANT.stats.totalMembers} / {planLimits.maxMembers}</span>
              </div>
              <div className="w-full bg-zinc-950 h-3 rounded-full overflow-hidden border border-white/5">
                <div className={`h-full rounded-full ${memberPercent > 90 ? 'bg-rose-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]' : 'bg-blue-600 shadow-[0_0_15px_rgba(59,130,246,0.5)]'} transition-all duration-1000`} style={{width: `${memberPercent}%`}}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-3 items-end">
                <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Células Ativas</span>
                <span className="text-xs font-black text-white">{MOCK_TENANT.stats.activeCells} / {planLimits.maxCells}</span>
              </div>
              <div className="w-full bg-zinc-950 h-3 rounded-full overflow-hidden border border-white/5">
                <div className={`h-full rounded-full ${cellPercent > 90 ? 'bg-rose-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]' : 'bg-indigo-600 shadow-[0_0_15px_rgba(99,102,241,0.5)]'} transition-all duration-1000`} style={{width: `${cellPercent}%`}}></div>
              </div>
            </div>
          </div>
          <button className="mt-12 w-full py-4 bg-zinc-800 text-zinc-300 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] border border-white/5 hover:bg-zinc-700 transition-all flex items-center justify-center gap-3">
            UPGRADE DISPONÍVEL <ArrowRight size={14} />
          </button>
        </div>

        <div className="bg-zinc-900 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl">
           <h4 className="font-black text-white text-xl mb-10 flex items-center gap-4 uppercase tracking-tighter">
            <div className="w-1.5 h-6 bg-emerald-600 rounded-full" /> Timeline de Atividade
          </h4>
          <div className="space-y-6">
            {[
              { label: 'Oferta Lançada', user: 'Líder João', date: 'Hoje, 10:24', icon: <DollarSign size={16} />, color: 'text-emerald-400 bg-emerald-500/10' },
              { label: 'Novo Membro', user: 'Sec. Maria', date: 'Hoje, 09:15', icon: <Users size={16} />, color: 'text-blue-400 bg-blue-500/10' },
              { label: 'Célula Ativada', user: 'Pr. André', date: 'Ontem', icon: <Layers size={16} />, color: 'text-indigo-400 bg-indigo-500/10' },
            ].map((activity, i) => (
              <div key={i} className="flex items-center justify-between border-b border-white/5 pb-4 last:border-0">
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-2xl ${activity.color}`}>{activity.icon}</div>
                  <div>
                    <p className="text-sm font-bold text-zinc-100">{activity.label}</p>
                    <p className="text-[10px] text-zinc-500 font-black uppercase tracking-tight">{activity.user}</p>
                  </div>
                </div>
                <span className="text-[10px] font-black text-zinc-600 uppercase tracking-tighter">{activity.date}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const PastorDashboard = () => {
  const ladderDist = [
    { stage: 'Ganhar', count: MOCK_MEMBERS.filter(m => m.stage === LadderStage.WIN).length, color: '#3b82f6' },
    { stage: 'Consolidar', count: MOCK_MEMBERS.filter(m => m.stage === LadderStage.CONSOLIDATE).length, color: '#10b981' },
    { stage: 'Discipular', count: MOCK_MEMBERS.filter(m => m.stage === LadderStage.DISCIPLE).length, color: '#f59e0b' },
    { stage: 'Enviar', count: MOCK_MEMBERS.filter(m => m.stage === LadderStage.SEND).length, color: '#ef4444' },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter uppercase">Pastoral Insights</h2>
          <p className="text-zinc-500 font-medium text-lg italic">Indicadores de saúde espiritual e crescimento.</p>
        </div>
        <div className="flex items-center gap-3 text-[10px] font-black text-zinc-400 bg-zinc-900 border border-white/5 px-5 py-3 rounded-2xl">
          <Calendar size={14} className="text-blue-500" /> JUNHO 2024
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <StatCard title="Total Membros" value={MOCK_TENANT.stats.totalMembers} trend={12} icon={<Users className="text-blue-400" />} color="bg-blue-500/10" />
        <StatCard title="Células Ativas" value={MOCK_TENANT.stats.activeCells} trend={8} icon={<Layers className="text-purple-400" />} color="bg-purple-500/10" />
        <StatCard title="Pedidos de Clamor" value={MOCK_PRAYER_REQUESTS.filter(r => r.status === PrayerStatus.PENDING).length} icon={<Heart className="text-rose-400" />} color="bg-rose-500/10" />
        <StatCard title="Alvos de Batismo" value="45" trend={15} icon={<Target className="text-indigo-400" />} color="bg-indigo-500/10" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 bg-zinc-900 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl">
          <h4 className="font-black text-white text-xl mb-12 flex items-center gap-4 uppercase tracking-tighter">
            <div className="w-1.5 h-6 bg-blue-600 rounded-full" /> Pipeline da Escada do Sucesso
          </h4>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ladderDist}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#27272a" />
                <XAxis dataKey="stage" axisLine={false} tickLine={false} tick={{fill: '#52525b', fontSize: 11, fontWeight: 'bold'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#52525b', fontSize: 11, fontWeight: 'bold'}} />
                <Tooltip cursor={{fill: 'rgba(255,255,255,0.05)'}} contentStyle={{ backgroundColor: '#18181b', border: 'none', borderRadius: '12px' }} />
                <Bar dataKey="count" radius={[12, 12, 4, 4]}>
                  {ladderDist.map((entry, index) => (
                    <RechartsCell key={`cell-${index}`} fill={entry.color} fillOpacity={0.8} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-indigo-900 via-indigo-950 to-black p-12 rounded-[3rem] text-white shadow-2xl relative overflow-hidden flex flex-col justify-between">
           <div className="absolute -top-10 -right-10 opacity-10"><Zap size={200} /></div>
           <div>
             <Zap size={48} className="mb-8 text-indigo-400 animate-pulse" />
             <h4 className="text-4xl font-black mb-2 tracking-tighter uppercase">Visão 2024</h4>
             <p className="text-indigo-300 text-sm mb-12 font-bold uppercase tracking-widest italic leading-relaxed">Meta: 100 células ativas e 1.200 discípulos em envio.</p>
             <div className="space-y-8">
                {[
                  { label: 'DISCÍPULOS', val: 45 },
                  { label: 'ESTRUTURA', val: 42 },
                ].map(meta => (
                  <div key={meta.label}>
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.3em] mb-3 opacity-60">
                      <span>{meta.label}</span>
                      <span>{meta.val}%</span>
                    </div>
                    <div className="w-full bg-white/5 h-3 rounded-full overflow-hidden border border-white/5">
                      <div className="bg-indigo-500 h-full rounded-full shadow-[0_0_20px_rgba(99,102,241,0.5)] transition-all duration-1000" style={{width: `${meta.val}%`}}></div>
                    </div>
                  </div>
                ))}
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

const LeaderDashboard = () => {
  const myCell = MOCK_CELLS[0];
  const members = MOCK_MEMBERS.filter(m => m.cellId === myCell.id);

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter uppercase">{myCell.name}</h2>
          <p className="text-zinc-500 font-medium text-lg">Cuidado e pastoreio local.</p>
        </div>
        <button className="px-8 py-4 bg-blue-600 text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:scale-105 transition-all">
          Lançar Relatório
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <StatCard title="Presença Média" value="88%" trend={2} icon={<Users className="text-emerald-400" />} color="bg-emerald-500/10" />
        <StatCard title="Visitantes" value="3" trend={50} icon={<TrendingUp className="text-blue-400" />} color="bg-blue-500/10" />
        <StatCard title="Transições" value="2" subValue="estágios" icon={<Target className="text-amber-400" />} color="bg-amber-500/10" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="bg-zinc-900 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl">
          <h4 className="font-black text-white text-xl mb-10 flex items-center gap-4 uppercase tracking-tighter">
            <div className="w-1.5 h-6 bg-blue-600 rounded-full" /> Meus Discípulos
          </h4>
          <div className="space-y-5">
            {members.map(m => (
              <div key={m.id} className="flex items-center justify-between p-4 hover:bg-white/5 rounded-[1.5rem] transition-all border border-transparent hover:border-white/5 group">
                <div className="flex items-center gap-4">
                  <img src={m.avatar} className="w-12 h-12 rounded-2xl ring-2 ring-white/10 group-hover:ring-blue-500 transition-all" alt="" />
                  <div>
                    <p className="text-sm font-black text-white uppercase">{m.name}</p>
                    <p className="text-[10px] text-zinc-500 font-black uppercase tracking-tighter">{m.stage}</p>
                  </div>
                </div>
                <button className="text-[10px] font-black text-blue-500 uppercase tracking-widest hover:text-white transition-colors">Ver Perfil</button>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-zinc-950 p-10 rounded-[3rem] border border-white/5 border-dashed relative">
          <h4 className="font-black text-white text-xl mb-10 flex items-center gap-4 uppercase tracking-tighter">
            <div className="w-1.5 h-6 bg-blue-600 rounded-full" /> Próxima Reunião
          </h4>
          <div className="bg-zinc-900 p-8 rounded-[2rem] border border-white/5 shadow-2xl relative group overflow-hidden">
             <div className="absolute -right-5 -top-5 opacity-5 group-hover:opacity-10 transition-opacity"><Clock size={120} /></div>
             <div className="flex items-center gap-6 mb-8">
                <div className="bg-blue-600 text-white w-20 h-20 rounded-[1.5rem] font-black flex flex-col items-center justify-center shadow-xl shadow-blue-500/20">
                   <p className="text-[10px] uppercase tracking-widest">Ter</p>
                   <p className="text-3xl tracking-tighter leading-none mt-1">11</p>
                </div>
                <div>
                   <p className="text-xl font-black text-white uppercase tracking-tight">{myCell.name}</p>
                   <p className="text-sm text-zinc-500 font-bold uppercase tracking-widest">{myCell.meetingTime} • {myCell.hostName}</p>
                </div>
             </div>
             <div className="flex items-center gap-3 text-xs text-zinc-400 mb-10 font-black uppercase tracking-widest">
                <MapPin size={16} className="text-rose-500" /> {myCell.address}
             </div>
             <button className="w-full py-5 bg-white text-zinc-950 rounded-[1.5rem] font-black text-xs uppercase tracking-widest hover:scale-105 transition-all shadow-xl shadow-white/5">
               Notificar via WhatsApp
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const MemberDashboard = ({ user }: { user: any }) => (
  <div className="space-y-10 animate-in fade-in duration-700">
    <div className="bg-zinc-100 p-12 md:p-16 rounded-[3.5rem] text-zinc-950 shadow-2xl relative overflow-hidden">
      <div className="absolute -top-10 -right-10 opacity-5"><Zap size={300} /></div>
      <h2 className="text-5xl font-black mb-4 tracking-tighter uppercase leading-[0.9]">Paz do Senhor, <br/>{user.name.split(' ')[0]}!</h2>
      <p className="text-zinc-600 max-w-lg mb-12 font-bold text-lg leading-relaxed italic">Sua caminhada é preciosa para nós. <br/>Veja seu progresso na Escada do Sucesso.</p>
      
      <div className="flex items-center gap-6 md:gap-10 overflow-x-auto pb-4 scrollbar-hide">
        <div className="flex flex-col items-center shrink-0">
           <div className="w-20 h-20 bg-emerald-600 text-white rounded-[1.5rem] flex items-center justify-center mb-4 shadow-xl shadow-emerald-500/20">
             <CheckCircle2 size={40} />
           </div>
           <span className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em]">Ganhar</span>
        </div>
        <div className="h-0.5 w-16 bg-zinc-300 shrink-0"></div>
        <div className="flex flex-col items-center shrink-0">
           <div className="w-20 h-20 bg-blue-600 text-white rounded-[1.5rem] flex items-center justify-center mb-4 shadow-xl shadow-blue-500/30 animate-pulse ring-4 ring-white">
             <Clock size={40} />
           </div>
           <span className="text-[10px] font-black text-zinc-950 uppercase tracking-[0.3em]">Consolidar</span>
        </div>
        <div className="h-0.5 w-16 bg-zinc-300 shrink-0"></div>
        <div className="flex flex-col items-center opacity-30 shrink-0">
           <div className="w-20 h-20 bg-zinc-400 text-white rounded-[1.5rem] flex items-center justify-center mb-4">
             <Target size={40} />
           </div>
           <span className="text-[10px] font-black text-zinc-950 uppercase tracking-[0.3em]">Discipular</span>
        </div>
      </div>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
      <div className="bg-zinc-900 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl">
        <h4 className="font-black text-white text-xl mb-10 flex items-center gap-4 uppercase tracking-tighter">
          <div className="w-1.5 h-6 bg-rose-500 rounded-full" /> Minhas Orações
        </h4>
        <div className="space-y-5">
           {MOCK_PRAYER_REQUESTS.slice(0, 2).map(r => (
             <div key={r.id} className="p-6 bg-zinc-950 rounded-[1.5rem] border border-white/5 shadow-inner">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">{new Date(r.createdAt).toLocaleDateString()}</span>
                  <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${r.status === PrayerStatus.IN_PRAYER ? 'bg-indigo-500/10 text-indigo-400' : 'bg-emerald-500/10 text-emerald-400'}`}>
                    {r.status}
                  </span>
                </div>
                <p className="text-sm text-zinc-300 font-medium italic leading-relaxed">"{r.request}"</p>
             </div>
           ))}
           <button className="w-full py-5 bg-zinc-800 border border-white/5 rounded-[1.5rem] text-[10px] font-black uppercase tracking-[0.3em] text-zinc-500 hover:text-white hover:bg-zinc-700 transition-all mt-4">
             Novo Pedido de Fé
           </button>
        </div>
      </div>

      <div className="bg-zinc-900 p-10 rounded-[2.5rem] border border-white/5 shadow-2xl">
        <h4 className="font-black text-white text-xl mb-10 flex items-center gap-4 uppercase tracking-tighter">
          <div className="w-1.5 h-6 bg-emerald-500 rounded-full" /> Minha Célula
        </h4>
        <div className="flex items-center gap-5 p-6 bg-blue-600 rounded-[2rem] text-white shadow-xl shadow-blue-500/20 mb-8">
           <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
            <Layers size={28} />
           </div>
           <div>
             <p className="text-xl font-black uppercase tracking-tight leading-none">Célula Renovo</p>
             <p className="text-[10px] text-blue-100 font-black uppercase tracking-[0.1em] mt-1">Líder: Pr. João Silva</p>
           </div>
        </div>
        <div className="space-y-5 px-4 mb-10">
          <div className="flex items-center gap-4 text-zinc-300 text-sm font-bold uppercase tracking-widest">
            <Calendar size={18} className="text-zinc-600" /> Terça-feira às 20h
          </div>
          <div className="flex items-center gap-4 text-zinc-300 text-sm font-bold uppercase tracking-widest">
            <MapPin size={18} className="text-zinc-600" /> Rua das Flores, 123
          </div>
        </div>
        <button className="w-full py-5 bg-white text-zinc-950 rounded-[1.5rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-white/5 hover:scale-105 transition-all">
          Como Chegar
        </button>
      </div>
    </div>
  </div>
);

const Dashboard: React.FC<{ user: any }> = ({ user }) => {
  const role = user.role;

  switch (role) {
    case UserRole.MASTER_ADMIN:
      return <MasterDashboard />;
    case UserRole.CHURCH_ADMIN:
      return <ChurchAdminDashboard />;
    case UserRole.PASTOR:
      return <PastorDashboard />;
    case UserRole.CELL_LEADER_DISCIPLE:
      return <LeaderDashboard />;
    case UserRole.MEMBER_VISITOR:
      return <MemberDashboard user={user} />;
    default:
      return <div className="p-20 text-center text-zinc-500 font-black uppercase tracking-[0.5em] animate-pulse">Acesso Restrito</div>;
  }
};

export default Dashboard;
